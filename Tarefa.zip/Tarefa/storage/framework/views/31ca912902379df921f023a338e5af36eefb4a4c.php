<?php $__env->startSection('content'); ?>

<h1>Bem Vindo</h1>
<p class="lead">Aqui a lista de todas as tarefas <a href="<?php echo e(action('TarefaController@criar')); ?>" >Adicionar nova tarefa?</a></p>

<?php $__currentLoopData = $tarefa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h3><?php echo e($task->nome); ?></h3>
    <p>Descrição: <?php echo e($task->descricao); ?></p>
    <p>Status: <?php echo e($task->status); ?></p>
    <p>
        <a href="<?php echo e(action('TarefaController@editar', ['id' => $task->id])); ?>" class="btn btn-primary">Editar Tarefa</a>
    </p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>