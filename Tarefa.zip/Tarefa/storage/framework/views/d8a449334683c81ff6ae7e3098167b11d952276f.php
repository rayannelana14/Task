<?php $__env->startSection('content'); ?>

<?php echo Form::model($tarefa, [
    'method' => 'PATCH',
    'action' => ['TarefaController@atualizar', $tarefa->id]
]); ?>


<div class="form-group">
    <?php echo Form::label('nome', 'Nome:', ['class' => 'control-label']); ?>

    <?php echo Form::text('nome', null, ['class' => 'form-control', 'disabled']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('descricao', 'Descrição:', ['class' => 'control-label']); ?>

    <?php echo Form::textarea('descricao', null, ['class' => 'form-control', 'disabled']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('status', 'Aberta', ['class' => 'control-label']); ?>

    <?php echo Form::radio('status', 'Aberta', true); ?>

    <?php echo Form::label('status', 'Concluída', ['class' => 'control-label']); ?>

    <?php echo Form :: radio ( 'status', 'Concluida'); ?>

</div>

<?php echo Form::submit('Atualizar', ['class' => 'btn btn-primary']); ?>


<?php echo Form::close(); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>