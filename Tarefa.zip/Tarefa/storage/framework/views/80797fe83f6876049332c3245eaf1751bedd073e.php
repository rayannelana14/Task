<!DOCTYPE html>
<html>
<head>
	<title>Teste</title>
</head>
<body>
<p>Testando</p>

</body>
</html>