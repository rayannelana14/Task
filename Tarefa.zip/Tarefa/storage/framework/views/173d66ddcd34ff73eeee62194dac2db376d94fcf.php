<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h3><?php echo e($tarefa->nome); ?></h3>
    <p><?php echo e($tarefa->descricao); ?></p>
    <p><?php echo e($tarefa->status); ?></p>
    <p>
        <a href="<?php echo e(action('TarefaController@tarefa'), $task->id)); ?>" class="btn btn-info">View Task</a>
        <a href="<?php echo e(action('TarefaController@editar'), $task->id)); ?>" class="btn btn-primary">Edit Task</a>
    </p>
    <hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>